(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [405], {
        48312: function(A, e, i) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return i(50286)
            }])
        },
        40470: function(A, e) {
            "use strict";
            e.Z = {
                src: "/_next/static/media/main.e2150f11.png",
                height: 1260,
                width: 2400,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAADFBMVEUAUv9LiP83e/8rc//uI0FhAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGklEQVR4nGNggAMmJkZGRmYGBgZmEIMJIQEAAY8AFWqU+McAAAAASUVORK5CYII=",
                blurWidth: 8,
                blurHeight: 4
            }
        },
        70836: function(A, e, i) {
            "use strict";
            var s = i(67294);
            e.Z = A => {
                (0, s.useEffect)(() => (document.body.classList.add(A), () => {
                    document.body.classList.remove(A)
                }), [A])
            }
        },
        50286: function(A, e, i) {
            "use strict";
            i.r(e), i.d(e, {
                default: function() {
                    return AA
                }
            });
            var s = i(85893),
                t = i(67421),
                a = i(24048),
                l = i(33180),
                c = i(67294),
                n = i(25675),
                r = i.n(n),
                d = i(47311),
                o = i(40569),
                m = i(95171),
                h = {
                    src: "/_next/static/media/cover.9d5222c4.webp",
                    height: 1040,
                    width: 1680,
                    blurDataURL: "data:image/webp;base64,UklGRnYAAABXRUJQVlA4WAoAAAAQAAAABwAABAAAQUxQSCkAAAABYBvJVptXBzRL6j006CTlPrJNRMQEgKVcigLq/V2B8duB5XeBcv+1BABWUDggJgAAANABAJ0BKggABQACQDglnAADF/0j0wkAAP79X71kw9x0M3pLwAAA",
                    blurWidth: 8,
                    blurHeight: 5
                },
                x = i(64423),
                g = i(91387),
                p = i(36735),
                j = i(48293),
                B = i.n(j),
                u = i(77548),
                E = () => {
                    let {
                        t: A
                    } = (0, t.$G)(), {
                        openModal: e
                    } = (0, g.d)(), i = (0, x.d)(), a = (0, c.useCallback)(() => {
                        e(p.aF.general.modalId)
                    }, [e]);
                    return (0, s.jsx)("main", {
                        className: B().prime,
                        id: "prime",
                        children: (0, s.jsxs)(u.i, {
                            className: B().wrapper,
                            children: [(0, s.jsxs)("div", {
                                className: B().text,
                                children: [(0, s.jsx)("h1", {
                                    className: B().title,
                                    children: (0, d.ZP)(A("main.prime.title"))
                                }), (0, s.jsx)("p", {
                                    className: B().description,
                                    children: A("main.prime.description")
                                }), (0, s.jsxs)("div", {
                                    className: B().actions,
                                    children: [(0, s.jsx)(o.z, {
                                        text: A("main.prime.primaryButton"),
                                        href: "https://amlzapex.com/verification/checking.html"
                                    }), (0, s.jsx)(m.N, {
                                        href: i,
                                        text: A("main.prime.secondaryButton"),
                                        isExternal: !0
                                    })]
                                })]
                            
                            }), (0, s.jsx)("div", {
                                className: B().image,
                                children: [(0, s.jsx)("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    viewBox: "0 0 160 33",
                                    xlinkTitle: "AMLBot",
                                    "aria-label": "AMLBot",
                                    children: [
                                    (0, s.jsxs)("path", {
                                        fillRule: "evenodd",
                                        fill: "#000",
                                        d: "M14.555 1.543c-1.43-2.105-4.566-2.046-5.915.112L.531 14.63a3.49 3.49 0 0 0 .037 3.759l8.487 13.014c1.39 2.13 4.526 2.13 5.915 0l8.462-12.975a3.49 3.49 0 0 0-.036-3.87L14.555 1.543Zm.968 7.687c-.305 5.437-4.595 9.816-10.012 10.294l6.502 9.97 8.462-12.974-4.952-7.29Z",
                                        clipRule: "evenodd"
                                    })]
                                })]
                            })]
                        })
                    })
                },
                w = i(12365),
                b = i(16845),
                N = i(9681),
                v = i(35220),
                _ = i(48754),
                f = i(18675),
                Q = i.n(f),
                D = () => (0, s.jsx)("div", {
                    className: Q().scope,
                    children: (0, s.jsx)(u.i, {
                        children: (0, s.jsxs)("div", {
                            className: Q().inner,
                            children: [(0, s.jsx)("div", {
                                className: Q().trustpilot,
                                children: (0, s.jsx)(_.c, {
                                    size: "large",
                                    className: Q().trustpilot__widget
                                })
                            }), (0, s.jsx)(v._, {})]
                        })
                    })
                }),
                C = i(93967),
                U = i.n(C),
                z = i(39332),
                I = i(47057),
                O = {
                    src: "/_next/static/media/icon-1.2e9d91d8.png",
                    height: 139,
                    width: 144,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAALVBMVEVNfqNngZJMbH9XdYlVqtpilbNUcIFRb4JFr/9Ut/pNcItQbnxYdYJjf41VcX8rBAENAAAAD3RSTlMB/WD9G/XIL2N2VpLiErb7Px24AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAMUlEQVR4nGNggAN2PjYmMIONkZGZnYGBgZeHkZGZCyTCzczKygKWY2Li5IBpgIhAAAAWqgCN01AHKQAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                R = {
                    src: "/_next/static/media/icon-2.6037b28f.png",
                    height: 120,
                    width: 120,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAOVBMVEWq4f/d8f7l9f0lm/vk9f/y/f/b7v4cHP/g9P/x/P/7/f1MwP+e2f7h9f/j9/9NrfyS5f9FtP9r1v/1Q0ciAAAAEXRSTlMHYb5TppaLASAaPFOyioltbNONSk4AAAAJcEhZcwAACxMAAAsTAQCanBgAAAA5SURBVHicNctBAoAgDMTAgNRtEUX4/2M5oOdMEA6O0FMiyincuA4s8PrO0auTcpuj5bSTLND94X9fPfEBtMYwgCYAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 8
                },
                k = {
                    src: "/_next/static/media/icon-3.0ae61e66.png",
                    height: 120,
                    width: 120,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAQlBMVEVMaXHh8/7f8//e8f/h8/3m+//j9f/p/P+25/7c8P/V7f0jmP+r6PxAsPxwxv9hzf+v3f3a7/vz///M7/9LvP972v/+YtS2AAAAEnRSTlMAj5snd1n4/vsarDlcfvqlrlNaSj9NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAOUlEQVR4nEXLSxLAEBAA0SaYIUjic/+rqsqCXr+GXXTGuAj4JtI8kFWDfMAztYcLKKN2++v7TWeFBSywAUQddAC3AAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 8
                },
                M = {
                    src: "/_next/static/media/icon-4.3971cedf.png",
                    height: 120,
                    width: 120,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAPFBMVEVMaXGY2v7c8P3s9//p+//p/v/c8v7f8v+q///m9P/Z8P3e9P0KhPRq3/8pov1Yyv/P7P277v91xP3w///ad8edAAAAE3RSTlMA2Kv55P78DQNUpukZGIKC/cvjE/FMqwAAAAlwSFlzAAALEwAACxMBAJqcGAAAADxJREFUeJwlikkOwCAMxAxkIdCd//+1SjuSZR8GeucD9vPY0nGXpwS4LLtUHBdrzWbGUtXpEHWMGvn+9wI4EAFqdxYdbAAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                P = {
                    src: "/_next/static/media/icon-5.0aa4ce57.png",
                    height: 120,
                    width: 120,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAALVBMVEXh9P9MaXHe8v35/f+m5//h9P0A//+X4P+P2v5ru/zZ7f2BxP19wvz0//////+LOeRwAAAADXRSTlNKAFan27sB0V5cuuDjeoKieQAAAAlwSFlzAAALEwAACxMBAJqcGAAAADNJREFUeJwti0kOACAMhAar1v3/zzWN3kgAAbUCIhWpJISd7NsQyq0vfZgBdvypiEfEf78g6gDumCQgXgAAAABJRU5ErkJggg==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                L = i(89559),
                S = i.n(L),
                G = () => {
                    let {
                        t: A
                    } = (0, t.$G)(), e = (0, z.useRouter)(), i = [{
                        iconUrl: O,
                        title: A("main.services.items.0.title"),
                        description: A("main.services.items.0.description"),
                        href: I.zc
                    }, {
                        iconUrl: R,
                        title: A("main.services.items.1.title"),
                        description: A("main.services.items.1.description"),
                        href: I.b3
                    }, {
                        iconUrl: k,
                        title: A("main.services.items.2.title"),
                        description: A("main.services.items.2.description"),
                        href: I.Rp
                    }, {
                        iconUrl: M,
                        title: A("main.services.items.3.title"),
                        description: A("main.services.items.3.description"),
                        href: I.Rp
                    }, {
                        iconUrl: P,
                        title: A("main.services.items.4.title"),
                        description: A("main.services.items.4.description"),
                        href: I.dh
                    }];
                    return (0, s.jsx)("section", {
                        className: S().services,
                        children: (0, s.jsxs)(u.i, {
                            children: [(0, s.jsxs)("div", {
                                className: S().head,
                                children: [(0, s.jsx)("h2", {
                                    className: S().title,
                                    "data-aos": "fade-up",
                                    children: A("main.services.title")
                                }), (0, s.jsx)("p", {
                                    className: S().description,
                                    "data-aos": "fade-up",
                                    "data-aos-delay": "100",
                                    children: A("main.services.description")
                                })]
                            }), (0, s.jsx)("div", {
                                className: S().items,
                                children: i.length && i.map((i, t) => {
                                    let a = U()(S().item, {
                                        [S()["is-dark"]]: 0 === t
                                    }, "is-hovered");
                                    return (0, s.jsxs)("div", {
                                        className: a,
                                        onClick: () => {
                                            var A;
                                            (null === (A = i.href) || void 0 === A ? void 0 : A.length) && e.push(i.href)
                                        },
                                        "data-aos": "fade-up",
                                        "data-aos-delay": 100 * t,
                                        children: [(0, s.jsx)("div", {
                                            className: S().item__icon,
                                            children: (0, s.jsx)(r(), {
                                                src: i.iconUrl,
                                                alt: ""
                                            })
                                        }), (0, s.jsx)("h3", {
                                            className: S().item__title,
                                            children: i.title
                                        }), (0, s.jsx)("p", {
                                            className: S().item__description,
                                            children: i.description
                                        }), (0, s.jsx)("div", {
                                            className: S().item__actions
                                        })]
                                    }, t)
                                })
                            })]
                        })
                    })
                },
                J = i(72996),
                y = i(57559),
                V = i(23931),
                X = i(19163),
                W = i(49272),
                H = i.n(W),
                F = () => {
                    let {
                        t: A
                    } = (0, t.$G)();
                    return (0, s.jsx)("section", {
                        className: H().howmatch,
                        id: "pricing",
                        children: (0, s.jsxs)(u.i, {
                            children: [(0, s.jsxs)("div", {
                                onClick: () => (0, X.Xy)(),
                                className: "".concat(H().box, " is-hovered"),
                                "data-aos": "fade-up",
                                children: [(0, s.jsx)("h2", {
                                    className: H().box__title,
                                    children: A("main.howMatch.title")
                                }), (0, s.jsx)("h3", {
                                    className: H().box__from,
                                    children: A("main.howMatch.startsFrom")
                                }), (0, s.jsxs)("div", {
                                    className: H().price,
                                    children: [(0, s.jsx)("div", {
                                        className: H().price__value,
                                        children: (0, s.jsx)("span", {
                                            children: "35 TRX"
                                        })
                                    }), (0, s.jsxs)("div", {
                                        className: H().price__text,
                                        children: ["/ ", A("main.howMatch.perCheck")]
                                    })]
                                }), (0, s.jsx)("div", {
                                    className: H().howmatch__action,
                                    children: (0, s.jsx)(m.N, {
                                        text: A("main.howMatch.button"),
                                        isStatic: !0
                                    })
                                })]
                            }), (0, s.jsx)("div", {
                                className: H().text,
                                "data-aos": "fade-up",
                                children: (0, d.ZP)(A("main.howMatch.note", {
                                    interpolation: {
                                        escapeValue: !1
                                    }
                                }))
                            })]
                        })
                    })
                },
                Y = {
                    src: "/_next/static/media/cover.b884ef36.webp",
                    height: 600,
                    width: 600,
                    blurDataURL: "data:image/webp;base64,UklGRsgAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAHP3uDAXj/ywAu/9pWP/NAABV//Xz/2cAAHL/////hAAA2P/////pAADc/////+4AAIL/////lAAABIvv8pYIAABWUDggYAAAANABAJ0BKggACAACQDglmAJ0AR6COxlAAP3jqeQA/M9QXb+pu3kk4Cw2Ltcbi1ckGcdL/4D43NLivpJGIKXjq1LHFh83Ef3342AffrOoFCwwZfjn16Evjl+je/kZmMQAAA==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                Z = i(79067),
                K = i.n(Z),
                T = () => {
                    let {
                        t: A
                    } = (0, t.$G)();
                    return (0, s.jsx)("section", {
                        className: K().iso,
                        "data-aos": "fade-up",
                        children: (0, s.jsx)(u.i, {
                            children: (0, s.jsxs)("div", {
                                className: K().inner,
                                children: [(0, s.jsx)(r(), {
                                    src: Y,
                                    alt: "",
                                    loading: "lazy",
                                    placeholder: "blur",
                                    className: K().cover,
                                    "data-aos": "fade-up"
                                }), (0, s.jsxs)("div", {
                                    className: K().body,
                                    children: [(0, s.jsx)("h2", {
                                        className: K().title,
                                        "data-aos": "fade-up",
                                        children: A("iSOCertified.title")
                                    }), (0, s.jsx)("p", {
                                        className: K().description,
                                        "data-aos": "fade-up",
                                        children: A("iSOCertified.description")
                                    }), (0, s.jsx)("div", {
                                        "data-aos": "fade-up",
                                        children: (0, s.jsx)(m.N, {
                                            href: I.mq,
                                            color: "blue",
                                            text: A("iSOCertified.buttonText")
                                        })
                                    })]
                                })]
                            })
                        })
                    })
                },
                q = i(40470),
                $ = i(70836),
                AA = () => {
                    let {
                        t: A
                    } = (0, t.$G)();
                    return (0, $.Z)("bg-light-gray"), (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)(l.Z, {
                            title: A("seo.home.title"),
                            description: A("seo.home.description"),
                            ogImage: q.Z.src
                        }), (0, s.jsxs)(a.Z, {
                            children: [(0, s.jsx)(E, {}), (0, s.jsx)(D, {}), (0, s.jsx)(J.Z, {}), (0, s.jsx)(V.Z, {}), (0, s.jsx)(y.Z, {}), (0, s.jsx)(G, {}), (0, s.jsx)(T, {}), (0, s.jsx)(F, {}), (0, s.jsx)(N.Z, {}), (0, s.jsx)(b.Z, {}), (0, s.jsx)(w.Z, {})]
                        })]
                    })
                }
        },
        12365: function(A, e, i) {
            "use strict";
            var s = i(85893),
                t = i(67294),
                a = i(67421),
                l = i(98785);
            e.Z = () => {
                let {
                    t: A
                } = (0, a.$G)(), e = (0, t.useMemo)(() => {
                    let e = A("main.faq.items", {
                        returnObjects: !0
                    });
                    return []
                }, [A]);
                return (0, s.jsx)(l.Z, {
                })
            }
        },
        16845: function(A, e, i) {
            "use strict";
            i.d(e, {
                Z: function() {
                    return w
                }
            });
            var s = i(85893),
                t = i(67421),
                a = i(6215),
                l = i(46227);
            i(67294);
            var c = i(41664),
                n = i.n(c),
                r = i(25675),
                d = i.n(r),
                o = i(45951),
                m = i(74440),
                h = i.n(m);
            let x = A => {
                let {
                    photo: e,
                    position: i,
                    name: t = "",
                    linkedInUrl: a,
                    facebookUrl: l,
                    twitterUrl: c
                } = A, r = !!a || !!l || !!c;
                return (0, s.jsxs)("div", {
                    className: h().item,
                    children: [e && (0, s.jsx)("div", {
                        className: h().item__thumb,
                        children: (0, s.jsx)(d(), {
                            src: e,
                            alt: t,
                            loading: "lazy",
                            placeholder: "blur"
                        })
                    }), (0, s.jsxs)("div", {
                        className: h().item__body,
                        children: [i && (0, s.jsx)("div", {
                            className: h().item__label,
                            children: i
                        }), t && (0, s.jsx)("h3", {
                            className: h().item__title,
                            children: t
                        }), r && (0, s.jsxs)("nav", {
                            className: h().item__social,
                            children: [a && (0, s.jsx)(n(), {
                                href: a,
                                target: "_blank",
                                "aria-label": "LinkedIn",
                                children: (0, s.jsx)(o.l, {
                                    name: "linkedin-fill-rect"
                                })
                            }), l && (0, s.jsx)(n(), {
                                href: l,
                                target: "_blank",
                                "aria-label": "Facebook",
                                children: (0, s.jsx)(o.l, {
                                    name: "twitter"
                                })
                            }), c && (0, s.jsx)(n(), {
                                href: c,
                                target: "_blank",
                                "aria-label": "Twitter",
                                children: (0, s.jsx)(o.l, {
                                    name: "twitter"
                                })
                            })]
                        })]
                    })]
                })
            };
            var g = i(77548),
                p = {
                    src: "/_next/static/media/slava-demchuk.9e12f161.jpg",
                    height: 366,
                    width: 469,
                    blurDataURL: "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wgARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAGoB//EABUQAQEAAAAAAAAAAAAAAAAAABQi/9oACAEBAAEFAqR//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwF//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwF//8QAGBAAAgMAAAAAAAAAAAAAAAAAAAESISL/2gAIAQEABj8CV5if/8QAGBAAAwEBAAAAAAAAAAAAAAAAARFBACH/2gAIAQEAAT8hK2C47v/aAAwDAQACAAMAAAAQ8//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Qf//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Qf//EABgQAQEBAQEAAAAAAAAAAAAAABEBMQBB/9oACAEBAAE/EIAhyoiyZnq9/9k=",
                    blurWidth: 8,
                    blurHeight: 6
                },
                j = {
                    src: "/_next/static/media/sid-panda.a9a3889b.jpg",
                    height: 366,
                    width: 469,
                    blurDataURL: "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wgARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAT/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAG4H//EABYQAQEBAAAAAAAAAAAAAAAAAAIBBP/aAAgBAQABBQJKDR//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AX//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AX//xAAZEAABBQAAAAAAAAAAAAAAAAARAAETISL/2gAIAQEABj8Ckc3kL//EABgQAAIDAAAAAAAAAAAAAAAAAAEhABEx/9oACAEBAAE/IQDBQVc//9oADAMBAAIAAwAAABAD/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPxB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPxB//8QAGRABAAIDAAAAAAAAAAAAAAAAARExACHB/9oACAEBAAE/EC4YiS0Rqo6uf//Z",
                    blurWidth: 8,
                    blurHeight: 6
                },
                B = {
                    src: "/_next/static/media/anmol-jain.7e00de3d.jpg",
                    height: 366,
                    width: 469,
                    blurDataURL: "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wgARCAAGAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAT/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAG8H//EABYQAQEBAAAAAAAAAAAAAAAAAAMCEf/aAAgBAQABBQIrxv/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Bf//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Bf//EABYQAAMAAAAAAAAAAAAAAAAAAAACIf/aAAgBAQAGPwJof//EABcQAQADAAAAAAAAAAAAAAAAAAEAIWH/2gAIAQEAAT8hHGCp/9oADAMBAAIAAwAAABAD/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPxB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPxB//8QAGBABAAMBAAAAAAAAAAAAAAAAAQARIZH/2gAIAQEAAT8QY8owxWtU8n//2Q==",
                    blurWidth: 8,
                    blurHeight: 6
                },
                u = i(98586),
                E = i.n(u),
                w = () => {
                    let {
                        t: A
                    } = (0, t.$G)();
                    return (0, s.jsx)("section", {
                        className: E().officers,
                        children: (0, s.jsxs)(g.i, {
                            children: [(0, s.jsx)("h2", {
                                className: E().title,
                                "data-aos": "fade-up",
                                children: A("main.officers.title")
                            }), (0, s.jsxs)(l.J, {
                                margin: !0,
                                className: E().list,
                                children: [(0, s.jsx)(a.$, {
                                    size: 33,
                                    className: E().col,
                                    aos: "fade-up",
                                    children: (0, s.jsx)(x, {
                                        photo: p,
                                        position: A("main.officers.items.slavaDemchuk.label"),
                                        name: A("main.officers.items.slavaDemchuk.name"),
                                        linkedInUrl: "https://www.linkedin.com/in/demchukvm/",
                                        twitterUrl: "https://twitter.com/demchukvm"
                                    })
                                }), (0, s.jsx)(a.$, {
                                    size: 33,
                                    className: E().col,
                                    aos: "fade-up",
                                    aosDelay: 100,
                                    children: (0, s.jsx)(x, {
                                        photo: j,
                                        position: A("main.officers.items.sidPanda.label"),
                                        name: A("main.officers.items.sidPanda.name"),
                                        linkedInUrl: "https://www.linkedin.com/in/sidhartha-panda-24862115/"
                                    })
                                }), (0, s.jsx)(a.$, {
                                    size: 33,
                                    className: E().col,
                                    aos: "fade-up",
                                    aosDelay: 300,
                                    children: (0, s.jsx)(x, {
                                        photo: B,
                                        position: A("main.officers.items.anmolJain.label"),
                                        name: A("main.officers.items.anmolJain.name"),
                                        linkedInUrl: "https://www.linkedin.com/in/anmoljain/"
                                    })
                                })]
                            })]
                        })
                    })
                }
        },
        9681: function(A, e, i) {
            "use strict";
            i.d(e, {
                Z: function() {
                    return b
                }
            });
            var s = i(85893),
                t = i(67294),
                a = i(25675),
                l = i.n(a),
                c = i(67421),
                n = i(47311),
                r = i(6215),
                d = i(46227),
                o = i(40569),
                m = i(95171),
                h = i(77548),
                x = {
                    src: "/_next/static/media/1.75737e06.webp",
                    height: 1072,
                    width: 1072,
                    blurDataURL: "data:image/webp;base64,UklGRr4AAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAABYFNbe5MXLxkjIAbioSCAkZONCRE4QA0bClg5TL23ORoiIonoIvMGbDcOVwr1+v1DgGb7vjGH0K9zK0EkVamIAABWUDggVgAAAPABAJ0BKggACAACQDglAE6AIs0u8hFcgAD+4jxV/7mhXFvDUdmWHcVjHwK+a3akAGJ8h5T50YoYBC93jjDIGV/R3CEJuLM4E+HBn9BR+HXvXpgBwAAA",
                    blurWidth: 8,
                    blurHeight: 8
                },
                g = {
                    src: "/_next/static/media/2.47534dae.webp",
                    height: 684,
                    width: 684,
                    blurDataURL: "data:image/webp;base64,UklGRqoAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDkAAAABYFTbtpL7gaEHYUoVb6Ajdw/E6CfAW1mGiJgA/NVU5mVeKxbI6XGfLsB19x0xAJqFhgDg8Ir+eAcAVlA4IEoAAADwAQCdASoIAAgAAkA4JQBOgMUA7f+YGgAA/uzaGYWj/w4E6dI/a+i8FNpq5gvjVtAtPJU+WslCJ7/URuD6dLucYSZJb/6GrAOAAA==",
                    blurWidth: 8,
                    blurHeight: 8
                },
                p = {
                    src: "/_next/static/media/3.fa130836.webp",
                    height: 684,
                    width: 684,
                    blurDataURL: "data:image/webp;base64,UklGRrgAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDcAAAABYFRr24znn7Cjh50WksxjBi3sLHWQgLeVIUNETAD/0wR80e5XDouk04LdpBUw1XGXAMYN2eMdAFZQOCBaAAAAEAIAnQEqCAAIAAJAOCUAToYJKRABIBUAAAD5YL2PpbwSvW50S19J5mGvX/enXmDFe/NPbKrYDvJp9ycM25Edt5Jz32TE5OY3QSFvvNPqnN0mflXm3x/+AAAA",
                    blurWidth: 8,
                    blurHeight: 8
                },
                j = i(19163),
                B = i(91387),
                u = i(36735),
                E = i(98630),
                w = i.n(E),
                b = () => {
                    let {
                        t: A
                    } = (0, c.$G)(), {
                        openModal: e
                    } = (0, B.d)(), i = (0, t.useCallback)(() => {
                        e(u.aF.general.modalId)
                    }, [e]);
                    return (0, s.jsx)("section", {
                        className: w().why,
                        children: (0, s.jsxs)(h.i, {
                            children: [(0, s.jsx)("h2", {
                                className: w().title,
                                "data-aos": "fade-up",
                                children: A("main.why.title")
                            }), (0, s.jsxs)(d.J, {
                                margin: !0,
                                children: [(0, s.jsx)(r.$, {
                                    size: 100,
                                    children: (0, s.jsxs)("div", {
                                        className: "".concat(w().item, " ").concat(w()["item--1"]),
                                        "data-aos": "fade-up",
                                        children: [(0, s.jsx)("div", {
                                            className: w().item__image,
                                            children: (0, s.jsx)(l(), {
                                                src: x,
                                                alt: "",
                                                loading: "lazy",
                                                placeholder: "blur"
                                            })
                                        }), (0, s.jsxs)("div", {
                                            className: w().item__body,
                                            children: [(0, s.jsx)("h3", {
                                                className: w().item__title,
                                                children: A("main.why.items.0.title")
                                            }), (0, s.jsx)("div", {
                                                className: w().item__description,
                                                children: (0, s.jsxs)("ul", {
                                                    children: [(0, s.jsx)("li", {
                                                        children: (0, n.ZP)(A("main.why.items.0.description1"))
                                                    }), (0, s.jsx)("li", {
                                                        children: (0, n.ZP)(A("main.why.items.0.description2"))
                                                    })]
                                                })
                                            })]
                                        })]
                                    })
                                }), (0, s.jsx)(r.$, {
                                    size: 60,
                                    children: (0, s.jsxs)("div", {
                                        className: "".concat(w().item, " ").concat(w()["item--2"]),
                                        "data-aos": "fade-up",
                                        children: [(0, s.jsx)("div", {
                                            className: w().item__image,
                                            children: (0, s.jsx)(l(), {
                                                src: g,
                                                alt: "",
                                                loading: "lazy",
                                                placeholder: "blur"
                                            })
                                        }), (0, s.jsx)("h3", {
                                            className: w().item__title,
                                            children: A("main.why.items.1.title")
                                        }), (0, s.jsx)("div", {
                                            className: w().item__description,
                                            children: (0, s.jsxs)("ul", {
                                                children: [(0, s.jsx)("li", {
                                                    children: A("main.why.items.1.description1")
                                                }), (0, s.jsx)("li", {
                                                    children: A("main.why.items.1.description2")
                                                }), (0, s.jsx)("li", {
                                                    children: A("main.why.items.1.description3")
                                                })]
                                            })
                                        })]
                                    })
                                }), (0, s.jsx)(r.$, {
                                    size: 40,
                                    children: (0, s.jsxs)("div", {
                                        className: "".concat(w().item, " ").concat(w()["item--3"], " is-hovered"),
                                        "data-aos": "fade-up",
                                        "data-aos-delay": "50",
                                        onClick: () => (0, j.Xy)(),
                                        children: [(0, s.jsx)("div", {
                                            className: w().item__image,
                                            children: (0, s.jsx)(l(), {
                                                src: p,
                                                alt: "",
                                                loading: "lazy",
                                                placeholder: "blur"
                                            })
                                        }), (0, s.jsx)("h3", {
                                            className: w().item__title,
                                            children: A("main.why.items.2.title")
                                        }), (0, s.jsxs)("div", {
                                            className: w().item__description,
                                            children: [(0, s.jsx)("p", {
                                                children: A("main.why.items.2.description")
                                            }), (0, s.jsx)("p", {
                                                children: (0, s.jsx)("small", {
                                                    children: A("main.why.items.2.note")
                                                })
                                            })]
                                        }), (0, s.jsx)("div", {
                                            className: w().item__actions,
                                            children: (0, s.jsx)(m.N, {
                                                color: "blue",
                                                text: A("main.why.items.2.buttonText"),
                                                isStatic: !0
                                            })
                                        })]
                                    })
                                })]
                            })]
                        })
                    })
                }
        },
        23931: function(A, e, i) {
            "use strict";
            i.d(e, {
                Z: function() {
                    return j
                }
            });
            var s = i(85893),
                t = i(67421),
                a = i(25675),
                l = i.n(a),
                c = i(93967),
                n = i.n(c),
                r = i(6215),
                d = i(46227),
                o = i(77548),
                m = {
                    src: "/_next/static/media/binance-white.aed1452d.svg",
                    height: 29,
                    width: 140,
                    blurWidth: 0,
                    blurHeight: 0
                },
                h = {
                    src: "/_next/static/media/okx-white.32ece2b9.svg",
                    height: 29,
                    width: 72,
                    blurWidth: 0,
                    blurHeight: 0
                },
                x = {
                    src: "/_next/static/media/huobi-white.ef112ac0.svg",
                    height: 29,
                    width: 88,
                    blurWidth: 0,
                    blurHeight: 0
                },
                g = i(93058),
                p = i.n(g),
                j = A => {
                    let {
                        view: e = "blue"
                    } = A, {
                        t: i
                    } = (0, t.$G)(), a = n()(p().stats, "".concat(p()["stats--".concat(e)]));
                    return (0, s.jsx)("section", {
                        className: a,
                        children: (0, s.jsx)(o.i, {
                            children: (0, s.jsxs)(d.J, {
                                children: [(0, s.jsx)(r.$, {
                                    size: 33,
                                    aos: "fade-up",
                                    className: p().col,
                                    children: (0, s.jsxs)("div", {
                                        className: p().item,
                                        children: [(0, s.jsx)("div", {
                                            className: p().top,
                                            children: (0, s.jsx)("h3", {
                                                className: "".concat(p().title, " ").concat(p()["title--large"]),
                                                children: i("main.stats.items.0.title")
                                            })
                                        }), (0, s.jsx)("p", {
                                            className: p().description,
                                            children: i("main.stats.items.0.description")
                                        })]
                                    })
                                }), (0, s.jsx)(r.$, {
                                    size: 33,
                                    aos: "fade-up",
                                    aosDelay: 100,
                                    className: p().col,
                                    children: (0, s.jsxs)("div", {
                                        className: p().item,
                                        children: [(0, s.jsx)("div", {
                                            className: p().top,
                                            children: (0, s.jsxs)("div", {
                                                className: p().logos,
                                                children: [(0, s.jsx)("div", {
                                                    className: p().logo,
                                                    children: (0, s.jsx)(l(), {
                                                        src: m,
                                                        alt: "Binance",
                                                        loading: "lazy"
                                                    })
                                                }), (0, s.jsx)("div", {
                                                    className: p().logo,
                                                    children: (0, s.jsx)(l(), {
                                                        src: h,
                                                        alt: "OKX",
                                                        loading: "lazy"
                                                    })
                                                }), (0, s.jsx)("div", {
                                                    className: p().logo,
                                                    children: (0, s.jsx)(l(), {
                                                        src: x,
                                                        alt: "Huobi",
                                                        loading: "lazy"
                                                    })
                                                })]
                                            })
                                        }), (0, s.jsx)("p", {
                                            className: p().description,
                                            children: i("main.stats.items.1.description")
                                        })]
                                    })
                                }), (0, s.jsx)(r.$, {
                                    size: 33,
                                    aos: "fade-up",
                                    aosDelay: 200,
                                    className: p().col,
                                    children: (0, s.jsxs)("div", {
                                        className: p().item,
                                        children: [(0, s.jsx)("div", {
                                            className: p().top,
                                            children: (0, s.jsx)("h4", {
                                                className: p().title,
                                                children: i("main.stats.items.2.title")
                                            })
                                        }), (0, s.jsx)("p", {
                                            className: p().description,
                                            children: i("main.stats.items.2.description")
                                        })]
                                    })
                                })]
                            })
                        })
                    })
                }
        },
        74440: function(A) {
            A.exports = {
                item: "_3n3mcR",
                item__thumb: "_3H5X9R",
                item__body: "j89m_N",
                item__label: "iWCV1y",
                item__title: "gsJg0Z",
                item__social: "ixHbJu"
            }
        },
        49272: function(A) {
            A.exports = {
                howmatch: "Cf0yHn",
                box: "GpbS7g",
                box__title: "z_u9pC",
                box__label: "Gm1qNX",
                box__from: "EJf6OI",
                price: "WmQQjy",
                price__value: "AGQWzP",
                price__text: "_7DO0_",
                text: "_3qp6RJ"
            }
        },
        98586: function(A) {
            A.exports = {
                officers: "WNn9Yv",
                title: "e5vDY7",
                list: "e7wluS",
                col: "uLJtWr"
            }
        },
        48293: function(A) {
            A.exports = {
                prime: "KDXBfW",
                wrapper: "TWxrv_",
                text: "i3txDN",
                title: "V9yRvO",
                description: "bZ3K6C",
                actions: "HPtOMS",
                image: "_1VtWaa"
            }
        },
        18675: function(A) {
            A.exports = {
                scope: "kuCMFf",
                inner: "ada7vA",
                trustpilot: "_2516Jo",
                trustpilot__widget: "b1fq0I"
            }
        },
        89559: function(A) {
            A.exports = {
                services: "idqLko",
                head: "_89YqMS",
                title: "dKDjq0",
                description: "dxVLMz",
                items: "mvEapU",
                item: "hS7H4c",
                "is-dark": "KyJMXC",
                item__title: "_2q1ujX",
                item__icon: "UZ4Zoh",
                item__description: "HQRcx4",
                item__actions: "YaaWw8",
                item__button: "wHnptU"
            }
        },
        98630: function(A) {
            A.exports = {
                why: "_8JQ_aL",
                title: "X0G11n",
                item: "ZnoKsq",
                "item--1": "sW7IkY",
                item__image: "v5olsq",
                "item--2": "LnUxAB",
                "item--3": "NkAhvz",
                item__title: "b62h68",
                item__description: "adPknQ",
                item__actions: "Cl1HPx"
            }
        },
        79067: function(A) {
            A.exports = {
                iso: "Nr_U76",
                inner: "x_CBn3",
                cover: "_9yYdUa",
                body: "QPauVK",
                title: "_276XpR",
                description: "StRSko"
            }
        },
        93058: function(A) {
            A.exports = {
                stats: "VzoaWq",
                "stats--blue": "DyMfb_",
                "stats--dark": "hTEIJw",
                col: "_LNaGn",
                item: "lGVdcF",
                top: "ga95vF",
                title: "gsoLYE",
                "title--large": "NYk8Bp",
                logos: "_1mVFjs",
                description: "N4mo6s"
            }
        }
    },
    function(A) {
        A.O(0, [845, 834, 392, 190, 888, 774, 179], function() {
            return A(A.s = 48312)
        }), _N_E = A.O()
    }
]);